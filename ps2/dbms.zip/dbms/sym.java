/** CUP generated class containing symbol constants. */
public class sym {
    /* terminals */
    public static final int WORK = 34;
    public static final int GTEQ = 45;
    public static final int CHAR = 6;
    public static final int LTEQ = 44;
    public static final int INTEGER = 15;
    public static final int LPAREN = 35;
    public static final int CLIKE = 7;
    public static final int UPDATE = 30;
    public static final int DELETE = 10;
    public static final int STAR = 39;
    public static final int WHERE = 33;
    public static final int RPAREN = 36;
    public static final int SEMICOLON = 40;
    public static final int NOT = 21;
    public static final int IS = 17;
    public static final int AND = 3;
    public static final int LT = 43;
    public static final int REAL_VAL = 50;
    public static final int OR = 23;
    public static final int COMMA = 37;
    public static final int BEGIN = 5;
    public static final int VARCHAR = 32;
    public static final int SELECT = 27;
    public static final int ID = 47;
    public static final int DOT = 38;
    public static final int INT_VAL = 49;
    public static final int EOF = 0;
    public static final int TABLE = 29;
    public static final int error = 1;
    public static final int DISTINCT = 11;
    public static final int LIKE = 19;
    public static final int LIMIT = 20;
    public static final int VALUES = 31;
    public static final int NULL = 22;
    public static final int EQ = 41;
    public static final int FROM = 13;
    public static final int REAL = 25;
    public static final int INTO = 16;
    public static final int INSERT = 14;
    public static final int CREATE = 9;
    public static final int DROP = 12;
    public static final int STRING = 48;
    public static final int KEY = 18;
    public static final int ALL = 2;
    public static final int AS = 4;
    public static final int COMMIT = 8;
    public static final int PRIMARY = 24;
    public static final int GT = 42;
    public static final int ROLLBACK = 26;
    public static final int NOTEQ = 46;
    public static final int SET = 28;
}

